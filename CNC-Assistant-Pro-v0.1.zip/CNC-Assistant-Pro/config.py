from dotenv import load_dotenv
import os
load_dotenv()
BOT_TOKEN=os.getenv("BOT_TOKEN")
if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN not found")
